/*import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Date;
//import java.io.FileNotFoundException;
//import java.io.FileNotFoundException;
/*import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.time.*;*/

/**
*@version 1.0
*@author Reyes Vera
*/
public class DriverGenerar {


	public static void main(String[] args) {
		TableroH tablero = null;
		System.out.println("Vamos a generar un KenKen:");

		Generar ge = new Generar();

		tablero = ge.genera();
	}



}
