
public class CrearKenken {
	
	MainController mc = null;
	
	public CrearKenken(MainController a){
		mc = a;
	}

	
	public void genera(String nomkenken, String a, int b){
		mc.genera(nomkenken, a, b);
	}
	
	
}
