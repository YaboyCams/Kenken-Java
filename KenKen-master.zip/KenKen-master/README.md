# KenKen-Q1-2015
Basic KenKen game implemented in java.

Para compilar todo ejecutar make all.
El controlador principal es Main.java.
