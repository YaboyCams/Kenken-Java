/**
*@author Marc Ortiz
*/
public class Puntuacio{
	public int facil;
	public int mig;
	public int dificil;
	public Puntuacio(){
		facil = mig = dificil = 0;
	}
}
