public interface Transaction {
  public void execute();
}
