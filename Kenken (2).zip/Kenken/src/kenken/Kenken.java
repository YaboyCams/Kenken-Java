/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kenken;

import java.util.regex.*;




/**
 *
 * @author callo
 */
public class Kenken {

    /**
     * @param args the command line arguments
     */
    public static boolean isValidTime(String time) {
        // Patrón para una hora en formato hh:mm:ss
        String pattern = "^(0[0-9]|1[0-2]):[0-5][0-9]:[0-5][0-9]$"; // Modificado para permitir 00 horas
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(time);
        if (m.matches()) {
            String[] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);
            if (hours < 5 || (hours == 5 && Integer.parseInt(parts[1]) == 0 && Integer.parseInt(parts[2]) == 0)) {
                return true; // La hora es válida y es menor o igual a 5 horas
            }
        }
        return false; // La hora no es válida
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Inicio v = new Inicio();
        v.setVisible(true);
        
        Configuracion config = new Configuracion("Facil","Timer","Derecha","Si","00","00","05");
        config.grabarConfiguracion(config); 
    }
    
}
