/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kenken;

import java.util.regex.*;




/**
 *
 * @author callo
 */
public class Kenken {

    /**
     * @param args the command line arguments
     */
    public static boolean isValidTime(String hoursStr, String minutesStr, String secondsStr) {
        try {
            int hours = Integer.parseInt(hoursStr);
            int minutes = Integer.parseInt(minutesStr);
            int seconds = Integer.parseInt(secondsStr);

            // Validar que las horas no sean mayores a 5
            if (hours > 5) {
                return false;
            }

            // Validar las horas (0-12)
            if (hours < 0 || hours > 12) {
                return false;
            }

            // Validar los minutos (0-59)
            if (minutes < 0 || minutes > 59) {
                return false;
            }

            // Validar los segundos (0-59)
            if (seconds < 0 || seconds > 59) {
                return false;
            }

            return true; // La hora es válida
        } catch (NumberFormatException e) {
            // Alguno de los valores no es un número
            return false;
        }
    }
    public static String StringNum(String tiempo) {
        if("00".equals(tiempo)){
            return "0";
        }
        else{
            if (tiempo.matches("^0\\d+$")) {
                // Si la cadena comienza con "0" seguido de uno o más dígitos, quita los ceros iniciales
                tiempo = tiempo.replaceFirst("^0+", "");
            }
            return tiempo;            
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        Inicio v = new Inicio();
        v.setVisible(true);
        
        Configuracion config = new Configuracion("Facil","Timer","Derecha","Si","00","00","05");
        config.grabarConfiguracion(config); 
    }
    
}
