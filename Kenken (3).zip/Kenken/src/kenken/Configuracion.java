/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kenken;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author callo
 */
public class Configuracion implements Serializable {
    private String dificultad;
    private String tiempo;
    private String lado;
    private String sonido;
    private String horas;
    private String minutos;
    private String segundos;
    
    public Configuracion(){}
    public Configuracion(String pDificultad, String pTiempo,String pLado,String pSonido,String pHoras,String pMinutos,String pSegundos){
        setDificultad(pDificultad);
        setLado(pLado);
        setTiempo(pTiempo);
        setSonido(pSonido);
        setHoras(pHoras);
        setMinutos(pMinutos);
        setSegundos(pSegundos);
        
    }
    public static Configuracion leerConfiguracion(){
        //fichero de lectura
        FileInputStream fichero = null;
        Configuracion contenido = null;
        
        try{
            
            fichero = new FileInputStream("kenken_configuracion.dat");
            //objeto de lectura
            ObjectInputStream sacarMaterial = new ObjectInputStream(fichero);
            contenido = (Configuracion) sacarMaterial.readObject();
            
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }          
        return contenido;
    }
    
     public void grabarConfiguracion(Configuracion config){
        // Objeto para sacar archivo
        FileOutputStream fichero = null;
        try{
            //Se abre paso a un archivo
            fichero = new FileOutputStream("kenken_configuracion.dat");
            //objeto de escritura
            ObjectOutputStream insertar = new ObjectOutputStream(fichero);
            //se escribe
            insertar.writeObject(config);
            System.out.println("Grabado exitoso"); 
            fichero.close();
        }
        catch(FileNotFoundException ex){
            ex.printStackTrace();
        }
        catch(IOException ex){
            ex.printStackTrace();
        }
        
        finally{
            try{
                fichero.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }        
    }
    public String getDificultad(){
        return dificultad;
    }
    public String getTiempo(){
        return tiempo;
    }
    public String getLado(){;
        return lado;
    }
    public String getSonido(){
        return sonido;
    }
    public void setDificultad(String pDificultad){
        dificultad = pDificultad;
    }
    public void setTiempo(String pTiempo){
        tiempo = pTiempo;
    }
    public void setLado(String pLado){
        lado = pLado;
    }
    public void setSonido(String pSonido){
        sonido = pSonido;
    }
    
    
    public String getHoras(){
        return horas;
    }
    public void setHoras(String pHoras){
        horas = pHoras;
    }
    public String getMinutos(){
        return minutos;
    }
    public void setMinutos(String pMinutos){
        minutos = pMinutos;
    }
    public String getSegundos(){
        return segundos;
    }
    public void setSegundos(String pSegundos){
        segundos = pSegundos;
    }
    
}
